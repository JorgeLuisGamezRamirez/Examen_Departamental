import controlador.ControladorDefinicionAtributos;

public class Main {
    public static void main(String[] args) {
        ControladorDefinicionAtributos controlador = new ControladorDefinicionAtributos();
        controlador.mostrarVista();
    }
}
