package modelo;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DefinicionAtributo {
    private String nombre;
    private String tipo; // "String" o "Integer"
    private boolean esIdentificadorUnico;
    private boolean requerido;
    
    // Constructor por defecto necesario para Jackson
    public DefinicionAtributo() {
        this("", "String", false, true);
    }
    
    // Constructor principal
    @JsonCreator
    public DefinicionAtributo(
        @JsonProperty("nombre") String nombre,
        @JsonProperty("tipo") String tipo,
        @JsonProperty("esIdentificadorUnico") boolean esIdentificadorUnico,
        @JsonProperty("requerido") boolean requerido) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.esIdentificadorUnico = esIdentificadorUnico;
        this.requerido = requerido;
    }
    
    @JsonProperty("nombre")
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    @JsonProperty("tipo")
    public String getTipo() {
        return tipo;
    }
    
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    @JsonProperty("esIdentificadorUnico")
    public boolean isEsIdentificadorUnico() {
        return esIdentificadorUnico;
    }
    
    public void setEsIdentificadorUnico(boolean esIdentificadorUnico) {
        this.esIdentificadorUnico = esIdentificadorUnico;
    }
    
    @JsonProperty("requerido")
    public boolean isRequerido() {
        return requerido;
    }
    
    public void setRequerido(boolean requerido) {
        this.requerido = requerido;
    }
}
