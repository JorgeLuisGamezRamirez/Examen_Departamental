package dao;

import modelo.Entidad;
import java.util.List;
import java.util.stream.Collectors;

public class EntidadDAO extends AbstractJsonDAO<Entidad> {
    private static final String ARCHIVO_ENTIDADES = "entidades.json";
    
    public EntidadDAO() {
        super(ARCHIVO_ENTIDADES, Entidad.class);
    }
    
    @Override
    public void guardar(Entidad entidad) {
        List<Entidad> entidades = obtenerTodos();
        entidades.add(entidad);
        guardarTodos(entidades);
    }
    
    @Override
    public Entidad obtenerPorId(String id) {
        return obtenerTodos().stream()
                           .filter(e -> id.equals(e.getAtributo("matricula")))
                           .findFirst()
                           .orElse(null);
    }
    
    @Override
    public void actualizar(Entidad entidad) {
        List<Entidad> entidades = obtenerTodos();
        for (int i = 0; i < entidades.size(); i++) {
            if (entidades.get(i).getAtributo("matricula")
                        .equals(entidad.getAtributo("matricula"))) {
                entidades.set(i, entidad);
                break;
            }
        }
        guardarTodos(entidades);
    }
    
    @Override
    public void eliminar(String id) {
        List<Entidad> entidades = obtenerTodos();
        entidades = entidades.stream()
                           .filter(e -> !id.equals(e.getAtributo("matricula")))
                           .collect(Collectors.toList());
        guardarTodos(entidades);
    }
}
