package dao;

import java.util.List;

public interface GenericoDAO<T> {
    void guardar(T objeto);
    T obtenerPorId(String id);
    List<T> obtenerTodos();
    void actualizar(T objeto);
    void eliminar(String id);
    void guardarTodos(List<T> objetos);
}
