package dao;

import modelo.DefinicionAtributo;
import java.util.List;
import java.util.stream.Collectors;

public class DefinicionAtributoDAO extends AbstractJsonDAO<DefinicionAtributo> {
    private static final String ARCHIVO_DEFINICIONES = "definiciones.json";
    
    public DefinicionAtributoDAO() {
        super(ARCHIVO_DEFINICIONES, DefinicionAtributo.class);
    }
    
    @Override
    public void guardar(DefinicionAtributo definicion) {
        List<DefinicionAtributo> definiciones = obtenerTodos();
        definiciones.add(definicion);
        guardarTodos(definiciones);
    }
    
    @Override
    public DefinicionAtributo obtenerPorId(String nombre) {
        return obtenerTodos().stream()
                           .filter(d -> nombre.equals(d.getNombre()))
                           .findFirst()
                           .orElse(null);
    }
    
    @Override
    public void actualizar(DefinicionAtributo definicion) {
        List<DefinicionAtributo> definiciones = obtenerTodos();
        for (int i = 0; i < definiciones.size(); i++) {
            if (definiciones.get(i).getNombre().equals(definicion.getNombre())) {
                definiciones.set(i, definicion);
                break;
            }
        }
        guardarTodos(definiciones);
    }
    
    @Override
    public void eliminar(String nombre) {
        List<DefinicionAtributo> definiciones = obtenerTodos();
        definiciones = definiciones.stream()
                                .filter(d -> !nombre.equals(d.getNombre()))
                                .collect(Collectors.toList());
        guardarTodos(definiciones);
    }
}
