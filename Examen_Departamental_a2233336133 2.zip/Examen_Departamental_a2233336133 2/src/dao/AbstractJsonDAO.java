package dao;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.DeserializationFeature;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractJsonDAO<T> implements GenericoDAO<T> {
    protected final ObjectMapper objectMapper;
    protected final String archivo;
    protected final Class<T> clase;
    
    protected AbstractJsonDAO(String nombreArchivo, Class<T> clase) {
        this.objectMapper = new ObjectMapper();

        this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.archivo = nombreArchivo;
        this.clase = clase;

        try {
            File file = new File(archivo);
            if (!file.exists()) {
                guardarTodos(new ArrayList<>());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void guardarTodos(List<T> objetos) {
        try {
            File file = new File(archivo);
            
            if (file.getParentFile() != null) {
                file.getParentFile().mkdirs();
            }
            objectMapper.writerWithDefaultPrettyPrinter()
                      .writeValue(file, objetos);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Error al guardar en " + archivo + ": " + e.getMessage(), e);
        }
    }
    
    @Override
    public List<T> obtenerTodos() {
        try {
            File file = new File(archivo);
            if (!file.exists()) {
                return new ArrayList<>();
            }
            CollectionType listType = objectMapper.getTypeFactory()
                                                .constructCollectionType(List.class, clase);
            return objectMapper.readValue(file, listType);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error al leer " + archivo + ": " + e.getMessage());
            
            return new ArrayList<>();
        }
    }
    
    
    @Override
    public abstract void guardar(T objeto);
    
    @Override
    public abstract T obtenerPorId(String id);
    
    @Override
    public abstract void actualizar(T objeto);
    
    @Override
    public abstract void eliminar(String id);
}
