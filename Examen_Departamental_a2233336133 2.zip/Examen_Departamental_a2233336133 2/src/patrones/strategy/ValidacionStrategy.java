package patrones.strategy;

public interface ValidacionStrategy {
    Object validar(String valor) throws IllegalArgumentException;
    String getMensajeError();
}
