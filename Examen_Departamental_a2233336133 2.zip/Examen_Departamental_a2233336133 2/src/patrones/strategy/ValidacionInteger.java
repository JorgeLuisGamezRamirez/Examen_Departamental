package patrones.strategy;

public class ValidacionInteger implements ValidacionStrategy {
    @Override
    public Object validar(String valor) throws IllegalArgumentException {
        if (valor == null || valor.trim().isEmpty()) {
            throw new IllegalArgumentException(getMensajeError());
        }
        try {
            return Integer.parseInt(valor.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(getMensajeError());
        }
    }

    @Override
    public String getMensajeError() {
        return "El valor debe ser un número entero válido";
    }
}
