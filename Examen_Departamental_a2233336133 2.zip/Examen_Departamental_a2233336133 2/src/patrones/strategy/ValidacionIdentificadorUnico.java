package patrones.strategy;

public class ValidacionIdentificadorUnico implements ValidacionStrategy {
    private final boolean required;

    public ValidacionIdentificadorUnico(boolean required) {
        this.required = required;
    }

    @Override
    public Object validar(String valor) throws IllegalArgumentException {
        if (valor == null || valor.trim().isEmpty()) {
            if (required) {
                throw new IllegalArgumentException(getMensajeError());
            }
            return null;
        }
        return valor.trim();
    }

    @Override
    public String getMensajeError() {
        return "El identificador es requerido y no puede estar vacío";
    }
}
