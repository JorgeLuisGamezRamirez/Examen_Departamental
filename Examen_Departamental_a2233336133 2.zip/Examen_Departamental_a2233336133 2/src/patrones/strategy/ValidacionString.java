package patrones.strategy;

public class ValidacionString implements ValidacionStrategy {
    @Override
    public Object validar(String valor) throws IllegalArgumentException {
        if (valor == null || valor.trim().isEmpty()) {
            throw new IllegalArgumentException(getMensajeError());
        }
        return valor.trim();
    }

    @Override
    public String getMensajeError() {
        return "El valor no puede estar vacío";
    }
}
