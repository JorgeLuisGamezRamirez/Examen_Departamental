package patrones.factory;

import modelo.Entidad;
import java.util.Map;

public class EntidadFactory {
    public static Entidad crearEntidad(Map<String, Object> atributos) {
        Entidad entidad = new Entidad();
        entidad.setAtributos(atributos);
        return entidad;
    }
}
