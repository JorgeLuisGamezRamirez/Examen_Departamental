package patrones.observer;

import modelo.Entidad;
import java.util.ArrayList;
import java.util.List;

public class EntidadSubject {
    private List<EntidadObserver> observers = new ArrayList<>();
    
    public void addObserver(EntidadObserver observer) {
        if (!observers.contains(observer)) {
            observers.add(observer);
        }
    }
    
    public void removeObserver(EntidadObserver observer) {
        observers.remove(observer);
    }
    
    public void notifyEntidadAgregada(Entidad entidad) {
        for (EntidadObserver observer : observers) {
            observer.onEntidadAgregada(entidad);
        }
    }
    
    public void notifyEntidadModificada(Entidad entidad) {
        for (EntidadObserver observer : observers) {
            observer.onEntidadModificada(entidad);
        }
    }
    
    public void notifyEntidadEliminada(Entidad entidad) {
        for (EntidadObserver observer : observers) {
            observer.onEntidadEliminada(entidad);
        }
    }
}
