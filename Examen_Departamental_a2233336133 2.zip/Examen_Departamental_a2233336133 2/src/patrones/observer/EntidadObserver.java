package patrones.observer;

import modelo.Entidad;

public interface EntidadObserver {
    void onEntidadAgregada(Entidad entidad);
    void onEntidadModificada(Entidad entidad);
    void onEntidadEliminada(Entidad entidad);
}
