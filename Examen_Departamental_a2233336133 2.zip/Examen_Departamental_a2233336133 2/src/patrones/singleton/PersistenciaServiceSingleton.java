package patrones.singleton;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import modelo.Entidad;
import modelo.DefinicionAtributo;
import java.io.File;
import java.util.List;
import java.util.ArrayList;

public class PersistenciaServiceSingleton {
    private static PersistenciaServiceSingleton instancia;
    private final ObjectMapper objectMapper;
    private static final String ARCHIVO_ENTIDADES = "entidades.json";
    private static final String ARCHIVO_DEFINICIONES = "definiciones.json";
    
    private PersistenciaServiceSingleton() {
        this.objectMapper = new ObjectMapper();
    }
    
    public static PersistenciaServiceSingleton getInstance() {
        if (instancia == null) {
            instancia = new PersistenciaServiceSingleton();
        }
        return instancia;
    }
    
    public void guardarEntidades(List<Entidad> entidades) {
        try {
            ObjectWriter writer = objectMapper.writerWithDefaultPrettyPrinter();
            writer.writeValue(new File(ARCHIVO_ENTIDADES), entidades);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<Entidad> cargarEntidades() {
        try {
            File archivo = new File(ARCHIVO_ENTIDADES);
            if (archivo.exists()) {
                return objectMapper.readValue(archivo,
                    objectMapper.getTypeFactory().constructCollectionType(List.class, Entidad.class));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }
    
    public void guardarDefiniciones(List<DefinicionAtributo> definiciones) {
        try {
            ObjectWriter writer = objectMapper.writerWithDefaultPrettyPrinter();
            writer.writeValue(new File(ARCHIVO_DEFINICIONES), definiciones);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<DefinicionAtributo> cargarDefiniciones() {
        try {
            File archivo = new File(ARCHIVO_DEFINICIONES);
            if (archivo.exists()) {
                return objectMapper.readValue(archivo,
                    objectMapper.getTypeFactory().constructCollectionType(List.class, DefinicionAtributo.class));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }
}
