package patrones.singleton;

import java.util.ArrayList;
import java.util.List;

public class ListaGenerica<T> {
    private List<T> elementos;
    
    public ListaGenerica() {
        this.elementos = new ArrayList<>();
    }
    
    public void insertar(T elemento) {
        elementos.add(elemento);
    }
    
    public void eliminar(T elemento) {
        elementos.remove(elemento);
    }
    
    public T buscar(int indice) {
        if (indice >= 0 && indice < elementos.size()) {
            return elementos.get(indice);
        }
        return null;
    }
    
    public void modificar(int indice, T nuevoElemento) {
        if (indice >= 0 && indice < elementos.size()) {
            elementos.set(indice, nuevoElemento);
        }
    }
    
    public List<T> obtenerTodos() {
        return new ArrayList<>(elementos);
    }
    
    public int tamaño() {
        return elementos.size();
    }
    
    public boolean estaVacia() {
        return elementos.isEmpty();
    }
    
    public void limpiar() {
        elementos.clear();
    }
}
