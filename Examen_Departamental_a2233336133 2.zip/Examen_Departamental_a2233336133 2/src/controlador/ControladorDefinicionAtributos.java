package controlador;

import modelo.DefinicionAtributo;
import vista.VistaDefinicionAtributos;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import dao.DefinicionAtributoDAO;

public class ControladorDefinicionAtributos {
    private VistaDefinicionAtributos vista;
    private List<DefinicionAtributo> definiciones;
    private DefinicionAtributoDAO definicionDAO;
    private List<DefinicionAtributo> definicionesAnteriores;

    public ControladorDefinicionAtributos() {
        this.vista = new VistaDefinicionAtributos();
        this.definicionDAO = new DefinicionAtributoDAO();
        this.definicionesAnteriores = definicionDAO.obtenerTodos();
        this.definiciones = new ArrayList<>();
        inicializarControlador();
    }
    
    private void inicializarControlador() {
        vista.getBotonAgregar().addActionListener(e -> agregarAtributo());
        vista.getBotonFinalizar().addActionListener(e -> finalizar());
        vista.getBotonRegresar().addActionListener(e -> regresar());
    }

    private void regresar() {
        if (!definiciones.isEmpty()) {
            int confirmacion = JOptionPane.showConfirmDialog(vista,
                "¿Desea guardar los cambios antes de regresar?",
                "Confirmar",
                JOptionPane.YES_NO_CANCEL_OPTION);
            
            if (confirmacion == JOptionPane.YES_OPTION) {
                if (validarDefiniciones()) {
                    definicionDAO.guardarTodos(definiciones);
                } else {
                    return;
                }
            } else if (confirmacion == JOptionPane.CANCEL_OPTION) {
                return;
            }
        }
        
        vista.dispose();
        new ControladorEntidades(definicionesAnteriores.isEmpty() ? definiciones : definicionesAnteriores);
    }

    private boolean validarDefiniciones() {
        if (definiciones.size() < 3) {
            mostrarError("Debe definir al menos tres atributos");
            return false;
        }
        
        if (definiciones.stream().noneMatch(DefinicionAtributo::isEsIdentificadorUnico)) {
            mostrarError("Debe definir un identificador único");
            return false;
        }
        return true;
    }
    
    private void agregarAtributo() {
        String nombre = vista.getCampoNombre().getText().trim();
        String tipo = (String) vista.getComboTipo().getSelectedItem();
        boolean esIdentificador = vista.getCheckIdentificador().isSelected();
        
        if (nombre.isEmpty()) {
            mostrarError("El nombre del atributo no puede estar vacío");
            return;
        }

        if (definiciones.stream().anyMatch(d -> d.getNombre().equals(nombre))) {
            mostrarError("Ya existe un atributo con ese nombre");
            return;
        }
        
        if (esIdentificador && definiciones.stream().anyMatch(DefinicionAtributo::isEsIdentificadorUnico)) {
            mostrarError("Ya existe un identificador único");
            return;
        }
        
        DefinicionAtributo nuevoAtributo = new DefinicionAtributo(nombre, tipo, esIdentificador, true);
        definiciones.add(nuevoAtributo);
        
        vista.getCampoNombre().setText("");
        vista.getCheckIdentificador().setSelected(false);
        vista.getCampoNombre().requestFocus();
        
        mostrarExito("Atributo agregado correctamente");
    }
    
    private void finalizar() {
        if (definiciones.size() < 3) {
            mostrarError("Debe definir al menos tres atributos");
            return;
        }
        
        if (definiciones.stream().noneMatch(DefinicionAtributo::isEsIdentificadorUnico)) {
            mostrarError("Debe definir un identificador único");
            return;
        }

        if (!definicionesAnteriores.isEmpty()) {
            if (JOptionPane.showConfirmDialog(vista,
                "Se detectaron definiciones anteriores. ¿Desea continuar?\n" +
                "Los datos existentes se migrarán a la nueva estructura.",
                "Confirmar Cambios",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE) != JOptionPane.YES_OPTION) {
                return;
            }
        }
        
        definicionDAO.guardarTodos(definiciones);
        vista.dispose();
        
        new ControladorEntidades(definiciones);
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(vista,
            mensaje,
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarExito(String mensaje) {
        JOptionPane.showMessageDialog(vista,
            mensaje,
            "Éxito",
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void mostrarVista() {
        vista.setVisible(true);
    }
}
