package controlador;

import modelo.Entidad;
import modelo.DefinicionAtributo;
import vista.VistaEntidades;
import patrones.factory.EntidadFactory;
import patrones.strategy.*;
import patrones.observer.EntidadSubject;
import dao.EntidadDAO;
import javax.swing.*;
import java.awt.Component;
import java.util.*;

public class ControladorEntidades {
    private VistaEntidades vista;    private List<Entidad> entidades;
    private List<DefinicionAtributo> definiciones;
    private EntidadDAO entidadDAO;
    private Map<String, ValidacionStrategy> estrategiasValidacion;
    private EntidadSubject entidadSubject;    public ControladorEntidades(List<DefinicionAtributo> definiciones) {
        this.definiciones = definiciones;
        this.entidadDAO = new EntidadDAO();
        this.entidades = entidadDAO.obtenerTodos();
        this.vista = new VistaEntidades(definiciones);
        this.entidadSubject = new EntidadSubject();
        this.entidadSubject.addObserver(vista);
        inicializarEstrategiasValidacion();
        inicializarControlador();
        cargarEntidades();
        mostrarVista();
    }
      private void inicializarEstrategiasValidacion() {
        estrategiasValidacion = new HashMap<>();
        for (DefinicionAtributo def : definiciones) {
            String nombre = def.getNombre();
            String tipo = def.getTipo();
            
            if (tipo.equals("Integer")) {
                estrategiasValidacion.put(nombre, new ValidacionInteger());
            } else if (def.isEsIdentificadorUnico()) {
                estrategiasValidacion.put(nombre, new ValidacionIdentificadorUnico(true));
            } else {
                estrategiasValidacion.put(nombre, new ValidacionString());
            }
        }
    }
    
    private void inicializarControlador() {
        vista.getBotonAgregar().addActionListener(e -> agregarEntidad());
        vista.getBotonActualizar().addActionListener(e -> actualizarEntidad());
        vista.getBotonEliminar().addActionListener(e -> eliminarEntidad());
        vista.getBotonRegresar().addActionListener(e -> regresarADefiniciones());
        vista.getTablaEntidades().getSelectionModel().addListSelectionListener(e -> seleccionarEntidad());
    }
    
    private void agregarEntidad() {
        try {
            Map<String, Object> atributos = recolectarAtributos();
            if (atributos == null) return;
            
            if (!validarIdentificadorUnico(atributos)) {
                JOptionPane.showMessageDialog(vista, 
                    "El identificador único ya existe o es inválido", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            Entidad nuevaEntidad = EntidadFactory.crearEntidad(atributos);
            entidades.add(nuevaEntidad);
            entidadDAO.guardarTodos(entidades);
            entidadSubject.notifyEntidadAgregada(nuevaEntidad);
            vista.limpiarCampos();
            JOptionPane.showMessageDialog(vista, 
                "Entidad agregada exitosamente", 
                "Éxito", 
                JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, 
                "Error al agregar la entidad: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void actualizarEntidad() {
        try {
            int filaSeleccionada = vista.getTablaEntidades().getSelectedRow();
            if (filaSeleccionada == -1) {
                JOptionPane.showMessageDialog(vista, 
                    "Seleccione una entidad para actualizar", 
                    "Aviso", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            Map<String, Object> atributos = recolectarAtributos();
            if (atributos == null) return;
            
            Entidad entidadActual = entidades.get(filaSeleccionada);
            String identificadorAntiguo = obtenerIdentificadorUnico(entidadActual.getAtributos());
            String identificadorNuevo = obtenerIdentificadorUnico(atributos);
            
            if (!identificadorAntiguo.equals(identificadorNuevo) && !validarIdentificadorUnico(atributos)) {
                JOptionPane.showMessageDialog(vista, 
                    "El nuevo identificador único ya existe o es inválido", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            entidadActual.setAtributos(atributos);
            entidadDAO.guardarTodos(entidades);
            entidadSubject.notifyEntidadModificada(entidadActual);
            vista.limpiarCampos();
            JOptionPane.showMessageDialog(vista, 
                "Entidad actualizada exitosamente", 
                "Éxito", 
                JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, 
                "Error al actualizar la entidad: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void eliminarEntidad() {
        try {
            int filaSeleccionada = vista.getTablaEntidades().getSelectedRow();
            if (filaSeleccionada == -1) {
                JOptionPane.showMessageDialog(vista, 
                    "Seleccione una entidad para eliminar", 
                    "Aviso", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            int confirmacion = JOptionPane.showConfirmDialog(vista,
                "¿Está seguro que desea eliminar esta entidad?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);
                
            if (confirmacion == JOptionPane.YES_OPTION) {
                Entidad entidadEliminada = entidades.get(filaSeleccionada);
                entidades.remove(filaSeleccionada);
                entidadDAO.guardarTodos(entidades);
                entidadSubject.notifyEntidadEliminada(entidadEliminada);
                vista.limpiarCampos();
                JOptionPane.showMessageDialog(vista, 
                    "Entidad eliminada exitosamente", 
                    "Éxito", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, 
                "Error al eliminar la entidad: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void seleccionarEntidad() {
        try {
            int filaSeleccionada = vista.getTablaEntidades().getSelectedRow();
            if (filaSeleccionada != -1) {
                Entidad entidad = entidades.get(filaSeleccionada);
                for (DefinicionAtributo def : definiciones) {
                    String nombre = def.getNombre();
                    Component campo = vista.getCampo(nombre);
                    if (campo instanceof JTextField) {
                        Object valor = entidad.getAtributo(nombre);
                        ((JTextField) campo).setText(valor != null ? valor.toString() : "");
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, 
                "Error al seleccionar la entidad: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private Map<String, Object> recolectarAtributos() {
        Map<String, Object> atributos = new HashMap<>();
        boolean datosValidos = true;
        StringBuilder errores = new StringBuilder("Se encontraron los siguientes errores:\n");

        for (DefinicionAtributo def : definiciones) {
            String nombre = def.getNombre();
            Component campo = vista.getCampo(nombre);
            
            if (campo instanceof JTextField) {
                String valor = ((JTextField) campo).getText().trim();
                
                // Validar campo requerido
                if (valor.isEmpty()) {
                    datosValidos = false;
                    errores.append("- El campo ").append(nombre).append(" es requerido\n");
                    continue;
                }
                
                
                try {
                    if (def.getTipo().equals("Integer")) {
                        try {
                            int valorInt = Integer.parseInt(valor);
                            atributos.put(nombre, valorInt);
                        } catch (NumberFormatException e) {
                            datosValidos = false;
                            errores.append("- El campo ").append(nombre).append(" debe ser un número entero\n");
                        }
                    } else {
                        
                        if (def.isEsIdentificadorUnico()) {
                            
                            atributos.put(nombre, valor);
                        } else {
                            atributos.put(nombre, valor);
                        }
                    }
                } catch (Exception e) {
                    datosValidos = false;
                    errores.append("- Error al procesar el campo ").append(nombre).append(": ").append(e.getMessage()).append("\n");
                }
            }
        }

        if (!datosValidos) {
            JOptionPane.showMessageDialog(vista, 
                errores.toString(), 
                "Error de validación", 
                JOptionPane.ERROR_MESSAGE);
            return null;
        }

        return atributos;
    }

    private boolean validarIdentificadorUnico(Map<String, Object> atributos) {
        String nuevoId = obtenerIdentificadorUnico(atributos);
        if (nuevoId.isEmpty()) {
            return false;
        }

        return entidades.stream()
            .map(e -> obtenerIdentificadorUnico(e.getAtributos()))
            .noneMatch(id -> id.equals(nuevoId));
    }

    private String obtenerIdentificadorUnico(Map<String, Object> atributos) {
        if (atributos == null) return "";
        
        Optional<DefinicionAtributo> defId = definiciones.stream()
            .filter(DefinicionAtributo::isEsIdentificadorUnico)
            .findFirst();
        
        if (!defId.isPresent()) return "";
        
        Object valor = atributos.get(defId.get().getNombre());
        return valor != null ? valor.toString() : "";
    }
    
    private void actualizarTabla() {
        vista.getModeloTabla().setRowCount(0);
        for (Entidad entidad : entidades) {
            Object[] fila = definiciones.stream()
                .map(def -> entidad.getAtributo(def.getNombre()))
                .toArray();
            vista.getModeloTabla().addRow(fila);
        }
    }
    
    private void cargarEntidades() {
        actualizarTabla();
    }
    
    private void limpiarFormulario() {
        Component[] componentes = vista.getPanelFormulario().getComponents();
        for (int i = 1; i < componentes.length; i += 2) {
            ((JTextField) componentes[i]).setText("");
        }
    }
    
    private void mostrarEntidadEnFormulario(Entidad entidad) {
        Component[] componentes = vista.getPanelFormulario().getComponents();
        for (int i = 0; i < componentes.length; i += 2) {
            JLabel etiqueta = (JLabel) componentes[i];
            JTextField campo = (JTextField) componentes[i + 1];
            String nombre = etiqueta.getText().replace(":", "");
            Object valor = entidad.getAtributo(nombre);
            campo.setText(valor != null ? valor.toString() : "");
        }
    }
    
    public void mostrarVista() {
        vista.setVisible(true);
    }

    public void migrarDatosAnteriores(List<DefinicionAtributo> definicionesAnteriores) {
        if (definicionesAnteriores == null || definicionesAnteriores.isEmpty()) {
            return;
        }

        // Obtener todas las entidades existentes
        List<Entidad> entidadesExistentes = entidadDAO.obtenerTodos();
        if (entidadesExistentes.isEmpty()) {
            return;
        }

        String idAntiguo = definicionesAnteriores.stream()
            .filter(DefinicionAtributo::isEsIdentificadorUnico)
            .map(DefinicionAtributo::getNombre)
            .findFirst()
            .orElse("");

        String idNuevo = definiciones.stream()
            .filter(DefinicionAtributo::isEsIdentificadorUnico)
            .map(DefinicionAtributo::getNombre)
            .findFirst()
            .orElse("");

    
        List<Entidad> entidadesMigradas = new ArrayList<>();
        for (Entidad entidadAntigua : entidadesExistentes) {
            Entidad entidadNueva = new Entidad();
            Map<String, Object> atributosNuevos = new HashMap<>();

            
            if (!idAntiguo.isEmpty() && !idNuevo.isEmpty()) {
                Object valorId = entidadAntigua.getAtributo(idAntiguo);
                if (valorId != null) {
                    atributosNuevos.put(idNuevo, valorId);
                }
            }

            
            for (DefinicionAtributo defNueva : definiciones) {
                String nombreNuevo = defNueva.getNombre();
                
                if (nombreNuevo.equals(idNuevo)) {
                    continue;
                }

                
                Optional<DefinicionAtributo> defAntigua = definicionesAnteriores.stream()
                    .filter(d -> d.getNombre().equals(nombreNuevo))
                    .findFirst();

                if (defAntigua.isPresent()) {
                    
                    Object valor = entidadAntigua.getAtributo(nombreNuevo);
                    if (valor != null) {
                        
                        if (defNueva.getTipo().equals("Integer") && valor instanceof String) {
                            try {
                                valor = Integer.parseInt((String)valor);
                            } catch (NumberFormatException e) {
                                valor = 0; 
                            }
                        }
                        atributosNuevos.put(nombreNuevo, valor);
                    }
                } else {
                    
                    if (defNueva.getTipo().equals("Integer")) {
                        atributosNuevos.put(nombreNuevo, 0);
                    } else {
                        atributosNuevos.put(nombreNuevo, "");
                    }
                }
            }

            entidadNueva.setAtributos(atributosNuevos);
            entidadesMigradas.add(entidadNueva);
        }

        
        entidades = entidadesMigradas;
        entidadDAO.guardarTodos(entidades);
        actualizarTabla();
        
        JOptionPane.showMessageDialog(vista, 
            "Se han migrado " + entidadesMigradas.size() + " registros a la nueva estructura.", 
            "Migración Completada", 
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void regresarADefiniciones() {
        vista.dispose();
        ControladorDefinicionAtributos controlador = new ControladorDefinicionAtributos();
        controlador.mostrarVista();
    }
}
