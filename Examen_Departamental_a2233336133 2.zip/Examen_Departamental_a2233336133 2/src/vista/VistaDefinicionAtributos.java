package vista;

import javax.swing.*;
import java.awt.*;

public class VistaDefinicionAtributos extends JFrame {
    private JTextField campoNombre;
    private JComboBox<String> comboTipo;
    private JCheckBox checkIdentificador;
    private JButton botonAgregar;
    private JButton botonFinalizar;
    private JButton botonRegresar;
    
    public VistaDefinicionAtributos() {
        configurarVentana();
        inicializarComponentes();
    }
    
    private void configurarVentana() {
        setTitle("Definición de Atributos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void inicializarComponentes() {
        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(240, 240, 245));
        
        // Panel de título
        JPanel panelTitulo = new JPanel();
        panelTitulo.setBackground(new Color(51, 122, 183));
        panelTitulo.setBounds(0, 0, 400, 40);
        
        JLabel titulo = new JLabel("Definición de Atributos del Sistema");
        titulo.setFont(new Font("Arial", Font.BOLD, 16));
        titulo.setForeground(Color.WHITE);
        panelTitulo.add(titulo);
        
        // Etiquetas y campos
        JLabel lblNombre = new JLabel("Nombre del Atributo:");
        lblNombre.setBounds(50, 60, 150, 25);
        lblNombre.setFont(new Font("Arial", Font.PLAIN, 12));
        
        campoNombre = new JTextField();
        campoNombre.setBounds(180, 60, 170, 25);
        
        JLabel lblTipo = new JLabel("Tipo de Dato:");
        lblTipo.setBounds(50, 95, 150, 25);
        lblTipo.setFont(new Font("Arial", Font.PLAIN, 12));
        
        comboTipo = new JComboBox<>(new String[]{"String", "Integer"});
        comboTipo.setBounds(180, 95, 170, 25);
        
        checkIdentificador = new JCheckBox("Es Identificador Único");
        checkIdentificador.setBounds(50, 130, 300, 25);
        checkIdentificador.setBackground(new Color(240, 240, 245));
        checkIdentificador.setFont(new Font("Arial", Font.PLAIN, 12));
        
        // Panel para los botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(null);
        panelBotones.setBackground(new Color(240, 240, 245));
        panelBotones.setBounds(0, 170, 400, 80);
        
        // Botón Agregar y Finalizar en la misma línea
        botonAgregar = new JButton("Agregar Atributo");
        botonAgregar.setBounds(50, 0, 145, 30);
        estilizarBoton(botonAgregar);
        
        botonFinalizar = new JButton("Finalizar");
        botonFinalizar.setBounds(205, 0, 145, 30);
        estilizarBoton(botonFinalizar);
        
        // Botón Regresar debajo
        botonRegresar = new JButton("Regresar");
        botonRegresar.setBounds(127, 40, 145, 30);
        estilizarBoton(botonRegresar);
        
        panelBotones.add(botonAgregar);
        panelBotones.add(botonFinalizar);
        panelBotones.add(botonRegresar);
        
        // Agregar componentes
        panel.add(panelTitulo);
        panel.add(lblNombre);
        panel.add(campoNombre);
        panel.add(lblTipo);
        panel.add(comboTipo);
        panel.add(checkIdentificador);
        panel.add(panelBotones);
        
        add(panel);
    }
    
    private void estilizarBoton(JButton boton) {
        boton.setBackground(new Color(51, 122, 183));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setFont(new Font("Arial", Font.BOLD, 12));
        
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(new Color(40, 96, 144));
            }
            
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(new Color(51, 122, 183));
            }
        });
    }
    
    // Getters
    public JTextField getCampoNombre() {
        return campoNombre;
    }
    
    public JComboBox<String> getComboTipo() {
        return comboTipo;
    }
    
    public JCheckBox getCheckIdentificador() {
        return checkIdentificador;
    }
    
    public JButton getBotonAgregar() {
        return botonAgregar;
    }
    
    public JButton getBotonFinalizar() {
        return botonFinalizar;
    }
    
    public JButton getBotonRegresar() {
        return botonRegresar;
    }
}
