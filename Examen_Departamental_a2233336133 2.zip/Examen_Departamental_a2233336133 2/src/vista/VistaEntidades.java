package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import modelo.Entidad;
import modelo.DefinicionAtributo;
import patrones.observer.EntidadObserver;

public class VistaEntidades extends JFrame implements EntidadObserver {
    private JTable tablaEntidades;
    private DefaultTableModel modeloTabla;
    private JPanel panelFormulario;
    private JButton botonAgregar;
    private JButton botonActualizar;
    private JButton botonEliminar;
    private JButton botonRegresar;
    private List<DefinicionAtributo> definiciones;
    private Map<String, Component> campos = new HashMap<>();

    public VistaEntidades(List<DefinicionAtributo> definiciones) {
        this.definiciones = definiciones;
        configurarVentana();
        inicializarComponentes(definiciones);
    }

    private void configurarVentana() {
        setTitle("Gestión de Entidades");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
    }

    private void inicializarComponentes(List<DefinicionAtributo> definiciones) {
        setLayout(new BorderLayout());

        // Configurar tabla
        String[] columnas = definiciones.stream()
                .map(DefinicionAtributo::getNombre)
                .toArray(String[]::new);

        // Crear un modelo de tabla que no permita edición
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tablaEntidades = new JTable(modeloTabla);
        
        // Configurar apariencia de la tabla
        configurarTabla();

        // Agregar la tabla a un panel con scroll
        JScrollPane scrollPane = new JScrollPane(tablaEntidades);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        add(scrollPane, BorderLayout.CENTER);

        // Panel de botones con espacio y bordes
        JPanel panelBotones = new JPanel();
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        botonAgregar = new JButton("Agregar");
        botonActualizar = new JButton("Actualizar");
        botonEliminar = new JButton("Eliminar");
        botonRegresar = new JButton("Regresar");

        // Configurar botones con el mismo tamaño
        Dimension buttonSize = new Dimension(100, 30);
        botonAgregar.setPreferredSize(buttonSize);
        botonActualizar.setPreferredSize(buttonSize);
        botonEliminar.setPreferredSize(buttonSize);
        botonRegresar.setPreferredSize(buttonSize);

        panelBotones.add(botonAgregar);
        panelBotones.add(Box.createHorizontalStrut(10)); // Espacio entre botones
        panelBotones.add(botonActualizar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(botonEliminar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(botonRegresar);

        add(panelBotones, BorderLayout.SOUTH);

        // Panel de formulario
        inicializarFormulario();
    }

    private void configurarTabla() {
        // Establecer el renderizador personalizado para centrar el contenido
        tablaEntidades.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            {
                setHorizontalAlignment(SwingConstants.CENTER);
            }
        });

        // Configurar el encabezado
        tablaEntidades.getTableHeader().setReorderingAllowed(false);
        tablaEntidades.getTableHeader().setResizingAllowed(false);
        tablaEntidades.getTableHeader().setDefaultRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            {
                setHorizontalAlignment(SwingConstants.CENTER);
                setBackground(new Color(230, 230, 230));
                setFont(getFont().deriveFont(Font.BOLD));
            }
        });

        // Configurar selección y grid
        tablaEntidades.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaEntidades.setRowHeight(25);
        tablaEntidades.setShowGrid(true);
        tablaEntidades.setGridColor(Color.LIGHT_GRAY);
        
        // Establecer el ancho de las columnas
        int tableWidth = tablaEntidades.getPreferredSize().width;
        int columnCount = tablaEntidades.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
            tablaEntidades.getColumnModel().getColumn(i).setPreferredWidth(tableWidth / columnCount);
            tablaEntidades.getColumnModel().getColumn(i).setMinWidth(100);
        }

        // Configurar colores alternados en las filas
        tablaEntidades.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value,
                        isSelected, hasFocus, row, column);
                
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(240, 240, 250));
                }
                
                setHorizontalAlignment(SwingConstants.CENTER);
                return c;
            }
        });
    }

    private void inicializarFormulario() {
        panelFormulario = new JPanel(new GridLayout(0, 2, 10, 5));
        panelFormulario.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        for (DefinicionAtributo def : definiciones) {
            JLabel etiqueta = new JLabel(def.getNombre() + ":", SwingConstants.RIGHT);
            etiqueta.setFont(etiqueta.getFont().deriveFont(Font.BOLD));
            
            JTextField campo = new JTextField(20);
            campo.setMargin(new Insets(2, 5, 2, 5));
            
            campos.put(def.getNombre(), campo);
            panelFormulario.add(etiqueta);
            panelFormulario.add(campo);
        }
        
        // Agregar el panel de formulario en un panel con padding
        JPanel panelContenedor = new JPanel(new BorderLayout());
        panelContenedor.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelContenedor.add(panelFormulario, BorderLayout.NORTH);
        
        add(panelContenedor, BorderLayout.NORTH);
    }

    // Getters para los componentes
    public JTable getTablaEntidades() {
        return tablaEntidades;
    }

    public DefaultTableModel getModeloTabla() {
        return modeloTabla;
    }

    public JPanel getPanelFormulario() {
        return panelFormulario;
    }

    public JButton getBotonAgregar() {
        return botonAgregar;
    }

    public JButton getBotonActualizar() {
        return botonActualizar;
    }

    public JButton getBotonEliminar() {
        return botonEliminar;
    }

    public JButton getBotonRegresar() {
        return botonRegresar;
    }

    public Component getCampo(String nombre) {
        return campos.get(nombre);
    }

    @Override
    public void onEntidadAgregada(Entidad entidad) {
        Object[] fila = definicionesToArray(entidad);
        modeloTabla.addRow(fila);
        limpiarCampos();
    }

    @Override
    public void onEntidadModificada(Entidad entidad) {
        int filaSeleccionada = tablaEntidades.getSelectedRow();
        if (filaSeleccionada != -1) {
            Object[] fila = definicionesToArray(entidad);
            for (int i = 0; i < fila.length; i++) {
                modeloTabla.setValueAt(fila[i], filaSeleccionada, i);
            }
        }
    }

    @Override
    public void onEntidadEliminada(Entidad entidad) {
        int filaSeleccionada = tablaEntidades.getSelectedRow();
        if (filaSeleccionada != -1) {
            modeloTabla.removeRow(filaSeleccionada);
            limpiarCampos();
        }
    }

    private Object[] definicionesToArray(Entidad entidad) {
        return definiciones.stream()
                .map(def -> entidad.getAtributo(def.getNombre()))
                .toArray();
    }

    public void limpiarCampos() {
        campos.values().stream()
                .filter(c -> c instanceof JTextField)
                .map(c -> (JTextField) c)
                .forEach(tf -> tf.setText(""));
    }
}
